GIUSTIZIA RIPARATIVA — PACCHETTO GITHUB PAGES

Contenuto:
- index.html : dashboard pronta da pubblicare

Per GitHub Pages:
1. Crea un nuovo repository su GitHub.
2. Carica index.html nella radice del repository.
3. Vai in Settings > Pages.
4. In Build and deployment scegli "Deploy from a branch".
5. Seleziona branch "main" e cartella "/ (root)".
6. Salva.
7. GitHub fornirà un indirizzo HTTPS del tipo:
   https://tuonome.github.io/nome-repository/

Aprendo sempre quell'indirizzo, il browser avrà un'origine HTTPS stabile
e potrà mantenere il token di sessione locale tra una visita e l'altra.

Nota:
- Il backend Google Apps Script deve rimanere pubblicato.
- Non modificare l'URL API dentro index.html senza motivo.
- In navigazione privata/incognito o se si cancellano i dati del sito,
  il login verrà richiesto nuovamente.
